//start game

//start in open field with
    //swoop bats and soft trolls