using system;
public class LevelBase
{
    public LevelBase () {
        Game.StartGame += RunLevel;
}

//start game

//start in open field with
    //swoop bats and soft trolls