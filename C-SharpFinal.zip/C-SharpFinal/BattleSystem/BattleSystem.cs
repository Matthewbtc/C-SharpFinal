using System;
public class BattleSystem {

public BattleSystem () {Game.StartGame += RunLevel;
}
private void RunLevel()
}
    Console.Writeline("The enemy is in sight, it is your move...")


//enemies drop items: useless, items, and sometimes weapons
//1. You found a bat webbing
//2. You have found a Potion. The Potion was added to your inventory
//3. You have found a Topaz Staff... Would you like to equip this? (if no, then toss)


//attacks go first, specials go second

//attack: genaric Attack

//special: players class specific attack

//defend: block an attack if non enemy specific

