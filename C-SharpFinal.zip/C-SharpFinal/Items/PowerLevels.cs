using System.Collections.Generic;
using System;
public class PowerLevels
{
    private List<string> power;

    public void RunList () {
        power = new List<string> ();

        

    }

    private void ChangeList (){
        Power.Add(Console.ReadLine());
        Console.Writeline(power.Count);

        foreach (string p in power)
        {
            Console.Writeline(p);
        }
    }

}