using System.Collections.Generic;

public class ItemList {}
{
    //list

    public List<string> listOfItems;

    public void RunList (){

        listOfItems = new List<string>();

        ChangeList();        
    }

    private void ChangeList (){
        Console.WriteLine(listOfItems.Count);

        foreach(string item in listOfItems){
            Console.WriteLine(weapon);
        }

        listOfItems.Add(Console.ReadLine());
        ChangeList();
    }

    //array
    public string[] arrayOfItems = {"Potion", "Spell Juice", "Quick Sand"};

    public void RunArray() {
    Console.WriteLine(arrayOfItems)

    foreach (string item in arrayOfItems)
        {
            Console.WriteLine(item)
        }
    }
}