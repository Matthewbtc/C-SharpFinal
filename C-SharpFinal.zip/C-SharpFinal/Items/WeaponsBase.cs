//Topaz
//Crystal
//Tungstun
//Nutron