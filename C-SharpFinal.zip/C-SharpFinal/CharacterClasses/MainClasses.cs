public class MainClasses



knight
// sword and shield bash:          - health, ^ attack, ^ defence, vv speed

mage
// spell cast:                     v health, ^ attack, ^ defence, - speed

knife expert
//twin blades and throwing knives: ^ health, - attack, - defence, ^^ speed

lancer
//jump and lance thrust:           v health, - attack, v defence, ^ speed