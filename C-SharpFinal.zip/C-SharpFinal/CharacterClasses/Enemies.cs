
class enemy
{
    attack=10
    health=1
    defence chance=100%
    weakness= special
}



class enemySwoopBat
{
 attack=5
    health=1
    defence chance=30%
    weakness= if (special= jump)
    {
        health=0
    }
}
//Air based, high evade
//

class enemyFranedBeast
{

}
//Ground based, quick attack, high evade

class enemySoftTroll
{

}
//Ground based, high defence

class enemySourMage
{

}
//Levitate based

class enemyCompoundDragon
{

}
//Ground/Air Based, 